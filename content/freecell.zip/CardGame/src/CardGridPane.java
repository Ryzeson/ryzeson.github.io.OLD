import java.util.ArrayList;
import java.util.Stack;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class CardGridPane extends GridPane 
{
	public StringProperty cardStr;
	public char [] rankName = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'};
	public char [] suitNameList = {'C', 'H', 'S', 'D'};
	public ArrayList<CardPane> cardPaneList = new ArrayList<>();
	public int fromRow, fromCol, toRow, toCol;
	public final KeyCombination CTRL_Z = new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN);
	public final KeyCombination U = new KeyCodeCombination(KeyCode.U);
	public Stack<String> strStack = new Stack<>();
	public Stack<String> posStack = new Stack<>(); 
	
	public Scene myScene = null;
	
	
	public CardGridPane(StringProperty[][] cardGrid)
	{
		ColumnConstraints col1 = new ColumnConstraints();
		col1.setPercentWidth(25);
		ColumnConstraints col2 = new ColumnConstraints();
		col2.setPercentWidth(25);
		ColumnConstraints col3 = new ColumnConstraints();
		col3.setPercentWidth(25);
		ColumnConstraints col4 = new ColumnConstraints();
		col4.setPercentWidth(25);
		super.getColumnConstraints().addAll(col1,col2,col3,col4);
		super.setVgap(10);
		super.setHgap(10);
		super.setPadding(new Insets(10, 10, 10, 10));
		
		//added row constraints
		RowConstraints row1 = new RowConstraints();
		row1.setPercentHeight(25);
		RowConstraints row2 = new RowConstraints();
		row2.setPercentHeight(25);
		RowConstraints row3 = new RowConstraints();
		row3.setPercentHeight(25);
		RowConstraints row4 = new RowConstraints();
		row4.setPercentHeight(25);

		super.getRowConstraints().addAll(row1,row2,row3,row4);
		super.setPadding(new Insets(10, 10, 10, 10));
		for(int i = 0; i < 4; i++)
		{
			for(int j = 0; j < 4; j++)
			{
				//CardPane card = new CardPane(cardGrid[i][j]); //changed i and j
				CardPane card = new CardPane(cardGrid[j][i]); //changed i and j
				//problem is that destsource col isnt changing
				card.setOnDragDetected(mouseEvent -> 
				{
					startFullDrag();
					Node source = (Node)mouseEvent.getSource() ;
					Integer colIndex = GridPane.getColumnIndex(source);
				    Integer rowIndex = GridPane.getRowIndex(source);
				    fromRow=(rowIndex);
				    fromCol=(colIndex);

					//System.out.println("{" + fromRow + ", " + fromCol + "}");
				});
				card.setOnMouseDragReleased(mouseEvent -> 
				{
					Node source = (Node)mouseEvent.getSource();
					Integer colIndex = GridPane.getColumnIndex(source);
				    Integer rowIndex = GridPane.getRowIndex(source);
				    toRow=(rowIndex);
				    toCol=(colIndex);
				    
				    //System.out.println("{" + toRow + ", " + toCol + "}");
				    
				    
					String from = cardGrid[fromRow][fromCol].get();
					String to = cardGrid[toRow][toCol].get();
					//System.out.println(from + " " + to);
					// check for same suit
					if(from.isEmpty() != true && to.isEmpty() != true)
					{
						char fromRank = from.charAt(0);
						char toRank = to.charAt(0);
						int fromRankNum = 0;
						int toRankNum = 0;
						for(int x = 0; x < rankName.length; x++)
						{
							if(rankName[x] == fromRank)
							{
								fromRankNum = x;
							}
						}
						for(int y = 0; y < rankName.length; y++)
						{
							if(rankName[y] == toRank)
							{
								toRankNum = y;
							}
						}

						if(from.charAt(1) == to.charAt(1))
						{
							if(from.equals(to) != true)
							{
								if(toRow == fromRow || toCol == fromCol)
								{
									//MOVE CARD
									//System.out.println("OK");
									String move = "" + fromRow + fromCol + toRow + toCol;
									posStack.push(move);
									strStack.push(cardGrid[toRow][toCol].get());
									cardGrid[toRow][toCol].set(cardGrid[fromRow][fromCol].get());
									//System.out.println(posStack.toString() + " " + strStack.toString());
									if(myScene == null)
									{
										myScene = this.getScene();

									}
									undo(cardGrid);
									// null exception
									// try catch
									cardGrid[fromRow][fromCol].set("");
								}
							}
							else
							{
								//System.out.println("false");
							}
						}
						else if(toRankNum - 1 == fromRankNum || toRankNum + 1 == fromRankNum || toRankNum == fromRankNum)
						{
							if(toRow == fromRow || toCol == fromCol)
							{
								if(toRow != fromRow || toCol != fromCol)
								{
									//MOVE CARD
									//System.out.println("OK");
									String move = "" + fromRow + fromCol + toRow + toCol;
									posStack.push(move);
									strStack.push(cardGrid[toRow][toCol].get());
									cardGrid[toRow][toCol].set(cardGrid[fromRow][fromCol].get());
									System.out.println(posStack.toString() + " " + strStack.toString());
									if(myScene == null)
									{
										myScene = this.getScene();

									}
									undo(cardGrid);
									// null expection
									// try catch

									// and re-render
									cardGrid[fromRow][fromCol].set("");
								}
							}	
						}
						else
						{
							//System.out.println("false");
						}
					}
				});

				//TODO
				if (myScene != null) {

				}
				cardPaneList.add(card);
				super.add(card, i, j); // add cards in 2d array to the correct corresponding spot in the gridPane
			}
		}
		//this.requestFocus();
	}
	
	public void undo(StringProperty[][] cardGrid)
	{
		myScene = this.getScene();
		this.getScene().setOnKeyPressed(e -> {
			//System.out.println("Key pressed: ");
			if(CTRL_Z.match(e))
			{
				//System.out.println("z");
				if(posStack.empty() != true && strStack.isEmpty() != true)
				{
					//System.out.println("pressed");
					String undoPos = posStack.pop();
					//System.out.println(undoPos);
					int fromPosCol =  undoPos.charAt(3) - '0';
					int fromPosRow = undoPos.charAt(2)- '0';
					int toPosCol = undoPos.charAt(1) - '0';
					int toPosRow = undoPos.charAt(0)- '0';
					//System.out.println("" + fromPosRow + " "+ fromPosCol);
					//System.out.println("" + toPosRow + " "+ toPosCol);

					String undoStrPro = strStack.pop();
					StringProperty undoStrProp = new SimpleStringProperty();
					undoStrProp.set(undoStrPro);
					
					cardGrid[toPosRow][toPosCol].set(cardGrid[fromPosRow][fromPosCol].get()); 
					cardGrid[fromPosRow][fromPosCol].set(undoStrProp.get());
							//StringProterty undoFromCard = new StringP

				}
			}
		});
		this.getScene().setOnKeyPressed(e ->{
			if(U.match(e))
			{
				if(posStack.empty() != true && strStack.isEmpty() != true)
				{
					//System.out.println("pressed");
					String undoPos = posStack.pop();
					//System.out.println(undoPos);
					int fromPosCol =  undoPos.charAt(3) - '0';
					int fromPosRow = undoPos.charAt(2)- '0';
					int toPosCol = undoPos.charAt(1) - '0';
					int toPosRow = undoPos.charAt(0)- '0';
					//System.out.println("" + fromPosRow + " "+ fromPosCol);
					//System.out.println("" + toPosRow + " "+ toPosCol);

					String undoStrPro = strStack.pop();
					StringProperty undoStrProp = new SimpleStringProperty();
					undoStrProp.set(undoStrPro);
					
					cardGrid[toPosRow][toPosCol].set(cardGrid[fromPosRow][fromPosCol].get()); 
					cardGrid[fromPosRow][fromPosCol].set(undoStrProp.get());
							//StringProterty undoFromCard = new StringP

				}
			}
		});
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
