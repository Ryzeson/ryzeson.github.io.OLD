import java.io.File;

import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class CardPane extends Pane
{
	/**
	 * Standard Poker card width/height is 635/889.
	 */
	public static final double ASPECT_RATIO = 635.0/889.0;
	public StringProperty cardStr;
	public double cardWidth;
	public double cardHeight;
	private String rankNameStr = "A23456789TJQK";
	private String suitNameStr = "CHSD";
	public char [] rankName = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'};
	public static Image[] images;
	public char [] suitNameList = {'C', 'H', 'S', 'D'};
	
	//TODO this folder doesn't work
	private static final String pathFolder = "/Freshman/Spring/CS 112/Practice/src/";
	//this file folder works
	//"/Accounts/turing/students/s22/gongha01/workspace/CS112/HW8/";
	//public String pathFolder = "/Accounts/turing/students/s22/gongha01/workspace/CS112/HW8/";
	public Image[] imagesFile = new Image[4];
	public Pane cardPane = new Pane();
	Stage primaryStage = new Stage();
	public Rectangle rectangle = new Rectangle();
	static
	{
		images = new Image[4];
		String [] suitFileName = {"green-club-100.png", "pink-heart-100.png", "black-spade-100.png", "blue-diamond-100.png"};
		for(int i = 0; i < 4; i++)
		{
			
			String filePath = pathFolder + suitFileName[i];
			images[i] = new Image(new File(filePath).toURI().toString());
		}
		//System.out.println(images.toString());
	}
	private void changeCard() 
	{
		this.getChildren().clear();
		
		String cardString = cardStr.getValue().toUpperCase();
		//check length 2
		if(cardString.length() == 2)
		{
			char rankChar = cardString.charAt(0);
			char suitChar = cardString.charAt(1);
			if((rankNameStr.contains(Character.toString(rankChar))) && (suitNameStr.contains(Character.toString(suitChar))))
			{
				int rank = 0;
				for(int i = 0; i < rankName.length; i++)
				{
					if(rankChar == rankName[i])
					{
						rank = i + 1;
					}
				}
				int index = 0;
				for(int i = 0; i < suitNameList.length; i++)
				{
					if(suitChar == suitNameList[i])
					{
						index = index + i;
					}
				}
//				String filePath = pathFolder + suitFileName[index];
//				Image suitImage = new Image(new File(filePath).toURI().toString());	
				double screenHeight = this.getHeight();
				double screenWidth = this.getWidth();
				if(screenWidth / screenHeight >= ASPECT_RATIO) // lay flat
				{
					cardWidth = screenHeight * ASPECT_RATIO;
					cardHeight = screenHeight;
				}
				else
				{
					cardHeight = screenWidth / ASPECT_RATIO;
					cardWidth = screenWidth ;
				}
				
				// grid pane for image
				
				rectangle.setWidth(cardWidth);
				rectangle.setHeight(cardHeight);

				rectangle.setTranslateX(screenWidth / 2 - cardWidth / 2);
				rectangle.setTranslateY(screenHeight / 2 - cardHeight / 2);

				rectangle.setStroke(Color.WHITE);
				rectangle.setFill(Color.WHITE);
				rectangle.setArcHeight(cardHeight / 10);
				rectangle.setArcWidth(cardHeight / 10 * ASPECT_RATIO);
				this.getChildren().add(rectangle);
				
				GridPane symbols = new GridPane();
//				System.out.println(screenWidth);
//				System.out.println(screenHeight);
//				System.out.println(screenWidth/screenHeight);

				symbols.setAlignment(Pos.CENTER);
				symbols.setTranslateX(screenWidth / 2 - cardWidth / 2 + cardWidth / 5); 
				symbols.setTranslateY(screenHeight / 2 - cardHeight / 2 + cardHeight / 10);
				symbols.setVgap(cardHeight / 30);
				symbols.setHgap(cardWidth / 30);
				
				for (int i = 0; i < rank; i++) 
				{
					ImageView view = new ImageView(images[index]);
					//ImageView view = new ImageView(suitImage);
					if (i % 3 == 0 && i != 0)
					{
						view.setFitWidth(cardWidth / 6);
						view.setFitHeight(cardHeight / 9);
						symbols.add(view, i % 3, i / 3);
					}
					else
					{
						ImageView view1 = new ImageView(images[index]);
						//ImageView view1 = new ImageView(suitImage);
						view1.setFitWidth(cardWidth / 6);
						view1.setFitHeight(cardHeight / 9);
						symbols.add(view1, i % 3, i / 3);
					}
				}
				this.getChildren().add(symbols);	
			}
		}
	}
	
	
	public CardPane(StringProperty cardStr) 
	{
		super();
		this.cardStr = cardStr;
		
		cardStr.addListener(new ChangeListener<String>(){
			public void changed(ObservableValue<? extends String> o, String oldVal, String newVal)
        	{
        		changeCard();
        	}
		});
		
		widthProperty().addListener(new ChangeListener<Number>(){ 
			public void changed(ObservableValue<? extends Number> o, Number oldVal, Number newVal)
        	{
        		changeCard();
        	}
		});
		
		heightProperty().addListener(new ChangeListener<Number>(){ 
			public void changed(ObservableValue<? extends Number> o, Number oldVal, Number newVal)
        	{
        		changeCard();
        	}
		});
		
		changeCard();
	}
}

